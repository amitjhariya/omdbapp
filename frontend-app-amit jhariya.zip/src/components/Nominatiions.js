import React from 'react';

const Nominations = () => {
	return (
		<>
			<span className='mr-2'>Add to Favourites</span>
			
		</>
	);
};

export default Nominations;