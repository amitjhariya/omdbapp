import React from 'react';

const RemoveNominations = () => {
	return (
		<>
			<span className='mr-2'>Remove from Nominations</span>
		</>
	);
};

export default RemoveNominations;