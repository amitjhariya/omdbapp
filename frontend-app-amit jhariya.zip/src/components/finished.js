import React from 'react';

const DoNominations = () => {
	return ( <div className='banner-text'>  <p> Finished!!!... You are done with nominations</p></div>);
};

export default DoNominations;